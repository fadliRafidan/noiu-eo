import bg from "@/images/backgrounds/why-choose-left-bg.jpg";
import bg2 from "@/images/shapes/why-choose-right-map.png";

const whyChoose = {
  bg,
  bg2,
  toggleText: " Trips \n & tours",
  title: "Why Choose Tevily",
  tagline: "Our benefit lists",
  description:
    "There are many variations of passages of Lorem Ipsum is simply free text available in the market for you, but the majority have suffered alteration in some form.",
  lists: [
    {
      id: 1,
      icon: "icon-travel",
      title: "Professional and Certified",
      description:
        "Lorem ipsum is simply free text dolor sit but the majority have suffered amet, consectetur notted.",
    },
    {
      id: 2,
      icon: "icon-travel-map",
      title: "Get Instant Tour Bookings",
      description:
        "Lorem ipsum is simply free text dolor sit but the majority have suffered amet, consectetur notted.",
    },
  ],
};

export default whyChoose;

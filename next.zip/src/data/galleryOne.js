import bg from "@/images/shapes/gallery-map.png";

const galleryOne = {
  bg,
  galleryData: [
    "gallery-one-img-1.jpg",
    "gallery-one-img-2.jpg",
    "gallery-one-img-3.jpg",
    "gallery-one-img-4.jpg",
    "gallery-one-img-5.jpg",
  ],
};

export default galleryOne;

import bg1 from "@/images/backgrounds/singapore-tour-bg.jpg";
import bg2 from "@/images/shapes/singapore-tour-right-shape.png";

const singaporeTour = {
  bg1,
  bg2,
  title: "Singapore",
  text: "A Simply Perfect Place \n To Get Lost",
  trustedBy: 4890,
};

export default singaporeTour;

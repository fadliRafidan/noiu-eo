import bg from "@/images/shapes/book-now-shape.png";

const bookNow = {
  bg,
  subtitle: "Plan your trip with us",
  title: "Ready for an unforgetable tour with noiu?",
};

export default bookNow;

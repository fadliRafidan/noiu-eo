const counterOne = [
  {
    id: 1,
    text: "Total Donations",
    count: 870,
  },
  {
    id: 2,
    text: "Campaigns Closed",
    count: 480,
  },
  {
    id: 3,
    text: "Happy People",
    count: 930,
  },
  {
    id: 4,
    text: "Our Volunteers",
    count: 63,
  },
];

export default counterOne;

const brandTwo = [
  "brand-2-1.png",
  "brand-2-2.png",
  "brand-2-3.png",
  "brand-2-4.png",
  "brand-2-5.png",
  "brand-2-1.png",
  "brand-2-2.png",
  "brand-2-3.png",
  "brand-2-4.png",
  "brand-2-5.png",
];

export default brandTwo;

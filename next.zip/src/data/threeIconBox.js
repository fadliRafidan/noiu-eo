const ThreeIconBox = [
  {
    id: 1,
    icon: "icon-cashback",
    title: "Best Price Guarantee",
    text: "There are many variations of but the majority have simply free text.",
  },
  {
    id: 2,
    icon: "icon-booking",
    title: "Easy & Quick Booking",
    text: "There are many variations of but the majority have simply free text.",
  },
  {
    id: 3,
    icon: "icon-travel",
    title: "Best Tour Selection",
    text: "There are many variations of but the majority have simply free text.",
  },
];

export default ThreeIconBox;

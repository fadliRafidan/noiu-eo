const newsTwo = {
  tagline: "From the blog post",
  title: "Latest News & Articles",
  description:
    "There are many latest variations of passages don’t do available but the majority have suffered alteration in some form, by injected humou or randomised.",
  newsData: [
    {
      id: 1,
      image: "news-one-img-1.jpg",
      date: "28 Aug",
      author: "Admin",
      comments: 2,
      title: "Things to See and Do When Visiting Japan",
    },
    {
      id: 2,
      image: "news-one-img-2.jpg",
      date: "28 Aug",
      author: "Admin",
      comments: 2,
      title: "Journeys are Best Measured in New Friends",
    },
    {
      id: 3,
      image: "news-one-img-3.jpg",
      date: "28 Aug",
      author: "Admin",
      comments: 2,
      title: "Travel the Most Beautiful Places in the World",
    },
    {
      id: 4,
      image: "news-one-img-1.jpg",
      date: "28 Aug",
      author: "Admin",
      comments: 2,
      title: "Things to See and Do When Visiting Japan",
    },
    {
      id: 5,
      image: "news-one-img-2.jpg",
      date: "28 Aug",
      author: "Admin",
      comments: 2,
      title: "Journeys are Best Measured in New Friends",
    },
    {
      id: 6,
      image: "news-one-img-3.jpg",
      date: "28 Aug",
      author: "Admin",
      comments: 2,
      title: "Travel the Most Beautiful Places in the World",
    },
  ],
};

export default newsTwo;

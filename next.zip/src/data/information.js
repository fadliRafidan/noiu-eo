const information = {
  address: "88 Broklyn Street \n Road New York. USA",
  phones: ["+92 666 888 0000", "666 888 0000"],
  mails: ["needhelp@tevily.com", "info@tevily.com"],
};

export default information;

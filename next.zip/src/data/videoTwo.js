import bg from "@/images/backgrounds/video-one-two-bg.jpg";

const videoTwo = {
  bg,
  videoId: "Get7rqXYrbQ",
  tagline: "Are you ready to travel?",
  title: "Tevily is a World Leading \n Online Tour Booking Platform",
};

export default videoTwo;

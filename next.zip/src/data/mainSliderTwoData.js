import bg1 from "@/images/backgrounds/tour-details-bg-1.jpg";
import bg2 from "@/images/backgrounds/tour-details-bg-2.jpg";
import bg3 from "@/images/backgrounds/tour-details-bg-3.jpg";

const mainSliderTwoData = [
  {
    id: 1,
    bg: bg1,
  },
  {
    id: 2,
    bg: bg2,
  },
  {
    id: 3,
    bg: bg3,
  },
];

export default mainSliderTwoData;

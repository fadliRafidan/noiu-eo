const newsPage = [
  {
    id: 1,
    image: "news-page-1.jpg",
    date: "28 Aug",
    author: "Admin",
    comments: 2,
    title: "Things to See and Do When Visiting Japan",
  },
  {
    id: 2,
    image: "news-page-2.jpg",
    date: "28 Aug",
    author: "Admin",
    comments: 2,
    title: "Journeys are Best Measured in New Friends",
  },
  {
    id: 3,
    image: "news-page-3.jpg",
    date: "28 Aug",
    author: "Admin",
    comments: 2,
    title: "Travel the Most Beautiful Places in the World",
  },
  {
    id: 4,
    image: "news-page-4.jpg",
    date: "28 Aug",
    author: "Admin",
    comments: 2,
    title: "Things to See and Do When Visiting Japan",
  },
  {
    id: 5,
    image: "news-page-5.jpg",
    date: "28 Aug",
    author: "Admin",
    comments: 2,
    title: "Journeys are Best Measured in New Friends",
  },
  {
    id: 6,
    image: "news-page-6.jpg",
    date: "28 Aug",
    author: "Admin",
    comments: 2,
    title: "Travel the Most Beautiful Places in the World",
  },
];

export default newsPage;

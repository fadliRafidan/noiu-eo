"use strict";
exports.id = 444;
exports.ids = [444];
exports.modules = {

/***/ 7253:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1664);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(358);
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap__WEBPACK_IMPORTED_MODULE_3__);




const SingleDestination = ({ destination ={}  })=>{
    const { image , title , price , _id , col  } = destination;
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Col, {
        xl: col,
        lg: col,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "destinations-one__single",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "destinations-one__img",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Image, {
                        src: `https://api.noiu-eo.com/${image}`,
                        alt: ""
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "destinations-one__content",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                            className: "destinations-one__title",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_1__["default"], {
                                href: `/tour-detail/${_id}`,
                                children: title
                            })
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "destinations-one__button",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                            href: `/tour-detail/${_id}`,
                            children: [
                                "Mulai dari ",
                                price
                            ]
                        })
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SingleDestination);


/***/ }),

/***/ 4822:
/***/ (() => {

const destinationsOne = [
    {
        id: 1,
        image: "destination-1-1.png",
        title: "Spain",
        tours: 6,
        col: 3
    },
    {
        id: 2,
        image: "destination-1-2.png",
        title: "Thailand",
        tours: 6,
        subTitle: "Wildlife",
        col: 6
    },
    {
        id: 3,
        image: "destination-1-3.png",
        title: "Africa",
        tours: 6,
        col: 3
    },
    {
        id: 4,
        image: "destination-1-4.png",
        title: "Australia",
        tours: 6,
        col: 6
    },
    {
        id: 5,
        image: "destination-1-5.png",
        title: "Switzerland",
        tours: 6,
        subTitle: "Adventure",
        col: 6
    },
    {
        id: 6,
        image: "destination-1-6.png",
        title: "Europe",
        tours: 6,
        col: 3
    },
    {
        id: 7,
        image: "destination-1-7.png",
        title: "San Francisco",
        tours: 6,
        subTitle: "Adventure",
        col: 6
    },
    {
        id: 8,
        image: "destination-1-8.png",
        title: "China",
        tours: 6,
        subTitle: "Tours",
        col: 3
    },
    {
        id: 9,
        image: "destination-1-9.png",
        title: "Germany",
        tours: 6,
        col: 6
    },
    {
        id: 10,
        image: "destination-1-10.png",
        title: "Dubai",
        tours: 6,
        col: 3
    }, 
];
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (destinationsOne)));


/***/ })

};
;
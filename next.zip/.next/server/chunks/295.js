"use strict";
exports.id = 295;
exports.ids = [295];
exports.modules = {

/***/ 9603:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/noiu.e8e8cc4f.png","height":55,"width":129,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAADCAYAAACuyE5IAAAAVklEQVR4nBWKIRJAABREd5OICwiKZGTHcAPJLTUjiUTRGEUx8veEN/Nm97kttk6KXPIkqYYHEkeMYZcE68C5MPZWzCG3+IHvePEHKcHLmEEFJ1zQWLo/zOsXTp7BZQIAAAAASUVORK5CYII="});

/***/ }),

/***/ 3289:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/footer-logo.2eb548ed.png","height":35,"width":132,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAACCAYAAABllJ3tAAAARklEQVR4nGPcUV76QlNJ/ot0Ylo8Myurwv9//64yMDJyMzAw2ALxTsalmZmX1ET5v5qUVIYx8PLp/f///ydQghmI5YH4GwDfsxSEWGWIMwAAAABJRU5ErkJggg=="});

/***/ }),

/***/ 1577:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/logo-2.544c553c.png","height":35,"width":132,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAACCAYAAABllJ3tAAAARklEQVR4nGPcUV76QlNJ/ot0Ylo8Myurwv9//64yMDJyMzAw2ALxTsalmZmX1ET5v5qUVIYx8PLp/f///ydQghmI5YH4GwDfsxSEWGWIMwAAAABJRU5ErkJggg=="});

/***/ }),

/***/ 8295:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Layout_Layout)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./src/context/context.js
var context = __webpack_require__(2280);
// EXTERNAL MODULE: ./src/assets/images/noiu.png
var noiu = __webpack_require__(9603);
// EXTERNAL MODULE: ./src/assets/images/resources/logo-2.png
var logo_2 = __webpack_require__(1577);
;// CONCATENATED MODULE: ./src/data/headerData.js


const navItems = [
    {
        id: 1,
        name: "Home",
        href: "/",
        subNavItems: []
    },
    {
        id: 2,
        name: "Dokumentasi",
        href: "/destinations",
        subNavItems: []
    },
    {
        id: 3,
        name: "Paket",
        href: "/tours",
        subNavItems: [
            {
                id: 1,
                name: "Paket Wisata",
                href: "/tours"
            },
            {
                id: 2,
                name: "Paket Outbound",
                href: "/tours-list"
            }, 
        ]
    },
    {
        id: 4,
        name: "Tentang Kami",
        href: "/about",
        subNavItems: []
    },
    {
        id: 5,
        name: "Artikel",
        href: "/news",
        subNavItems: []
    },
    {
        id: 6,
        name: "Kontak",
        href: "/contact",
        subNavItems: []
    }, 
];
const social = [
    {
        icon: "fa-facebook-square",
        link: ""
    },
    {
        icon: "fa-twitter",
        link: ""
    },
    {
        icon: "fa-instagram",
        link: ""
    },
    {
        icon: "fa-pinterest-p",
        link: ""
    }, 
];
const headerData = {
    icons: [
        {
            id: 1,
            icon: "icon-phone-call",
            content: "+ 92 666 999 0000",
            subHref: "tel"
        },
        {
            id: 2,
            icon: "icon-at",
            content: "needhelp@company.com",
            subHref: "mailto"
        }, 
    ],
    navItems,
    social,
    logo: noiu/* default */.Z,
    logo2: logo_2["default"]
};
/* harmony default export */ const data_headerData = (headerData);

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./src/hooks/useScroll.js

const useScroll = (scrollSize = 0)=>{
    const { 0: scrollTop , 1: setScrollTop  } = (0,external_react_.useState)(false);
    const handleSet = (0,external_react_.useCallback)(()=>{
        if ((window === null || window === void 0 ? void 0 : window.scrollY) > scrollSize) {
            setScrollTop(true);
        } else {
            setScrollTop(false);
        }
    }, [
        scrollSize
    ]);
    (0,external_react_.useEffect)(()=>{
        handleSet();
        window.addEventListener("scroll", handleSet);
        return ()=>window.removeEventListener("scroll", handleSet)
        ;
    }, [
        handleSet
    ]);
    return scrollTop;
};
/* harmony default export */ const hooks_useScroll = (useScroll);

// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: external "react-bootstrap"
var external_react_bootstrap_ = __webpack_require__(358);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
;// CONCATENATED MODULE: ./src/components/Header/NavItem.js




const NavItem = ({ navItem ={}  })=>{
    const { pathname  } = (0,router_.useRouter)();
    const { name , href , subNavItems  } = navItem;
    const subHref = subNavItems.map((item)=>item.href
    );
    const current = pathname === href || subHref.includes(pathname);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
        className: `dropdown${current ? " current" : ""}`,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                href: href,
                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                    href: href,
                    children: name
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                children: subNavItems.map((subItem)=>{
                    var ref, ref1;
                    /*#__PURE__*/ return (0,jsx_runtime_.jsxs)("li", {
                        className: ((ref = subItem.subItems) === null || ref === void 0 ? void 0 : ref.length) ? "dropdown" : "",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                href: subItem.href,
                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    href: href,
                                    children: subItem.name
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                                children: (ref1 = subItem.subItems) === null || ref1 === void 0 ? void 0 : ref1.map((item)=>/*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                            href: item.href,
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                href: href,
                                                children: item.name
                                            })
                                        })
                                    }, item.id)
                                )
                            })
                        ]
                    }, subItem.id);
                })
            })
        ]
    });
};
/* harmony default export */ const Header_NavItem = (NavItem);

// EXTERNAL MODULE: external "axios"
var external_axios_ = __webpack_require__(2167);
var external_axios_default = /*#__PURE__*/__webpack_require__.n(external_axios_);
;// CONCATENATED MODULE: ./src/components/Header/Header.js










const { icons , navItems: Header_navItems , social: Header_social , logo , logo2  } = data_headerData;
const Header = ({ pageTitle  })=>{
    const scrollTop = hooks_useScroll(130);
    const { toggleMenu , toggleSearch  } = (0,context/* useRootContext */.E)();
    const { 0: data , 1: setData  } = (0,external_react_.useState)("");
    const getBlog = async ()=>{
        const response = await external_axios_default().get('https://api.noiu-eo.com/v1/kontak/posts?page=1&perPage=15').then((result)=>{
            // console.log("data api", result.data);
            setData(result.data.data);
        // console.log(result.data.data);
        }).catch((err)=>{
            console.log("error", err);
        });
    };
    (0,external_react_.useEffect)(()=>{
        getBlog();
    }, []);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("header", {
        className: `main-header${pageTitle === "Home Two" ? " main-header-two" : ""} clearfix`,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "main-header__top",
                children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Container, {
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "main-header__top-inner clearfix",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "main-header__top-left",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                                    className: "list-unstyled main-header__top-address",
                                    children: data && data.map((row)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: "text",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        children: row.nomor
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: "text",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        children: row.email
                                                    })
                                                })
                                            ]
                                        }, row._id)
                                    )
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "main-header__top-right",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "main-header__top-right-inner",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "main-header__top-right-social"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "main-header__top-right-btn-box",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                href: "#",
                                                className: "thm-btn main-header__top-right-btn",
                                                children: "Number One Its You"
                                            })
                                        })
                                    ]
                                })
                            })
                        ]
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("nav", {
                className: scrollTop ? `stricky-header stricked-menu main-menu${pageTitle === "Home Two" ? " main-menu-two" : ""} stricky-fixed slideInDown animated clearfix` : `main-menu${pageTitle === "Home Two" ? " main-menu-two" : ""} slideIn animated clearfix`,
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: scrollTop ? "sticky-header__content main-menu-wrapper clearfix" : "main-menu-wrapper clearfix",
                    children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Container, {
                        className: "clearfix",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "main-menu-wrapper-inner clearfix",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "main-menu-wrapper__left clearfix",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "main-menu-wrapper__logo",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                            href: "/",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Image, {
                                                    // src={noiu}
                                                    src: (__webpack_require__(9603)/* ["default"].src */ .Z.src),
                                                    // src='../../assets/images/noiu.png'
                                                    // width="500" height="500"
                                                    alt: "Noiu"
                                                })
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "main-menu-wrapper__main-menu",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                onClick: ()=>toggleMenu()
                                                ,
                                                className: "mobile-nav__toggler",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                    className: "fa fa-bars"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                                                className: "main-menu__list",
                                                children: Header_navItems.map((navItem)=>/*#__PURE__*/ jsx_runtime_.jsx(Header_NavItem, {
                                                        navItem: navItem
                                                    }, navItem.id)
                                                )
                                            })
                                        ]
                                    })
                                ]
                            })
                        })
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const Header_Header = (Header);

;// CONCATENATED MODULE: ./src/assets/images/loader.png
/* harmony default export */ const loader = ({"src":"/_next/static/media/loader.9d1b84e3.png","height":135,"width":146,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAHCAYAAAA1WQxeAAAA8klEQVR4nAHnABj/Af///wDiAQFjCmVThP///hj7+vnv//8AkBsK/IIBthcBAfjk4mn7ta+W4ZxxAAcTK/8WHyYB/v7+AAT9+oPO+gl+Af3//+/t6OkQBPPw/cG8vwPramn+DygYAtERKAC0AQqSAf/////W3N7+6OvsAvn39wDb3uAAGxUT/x328gHwvLdJAfTJxdYGDA0p+QAA+gQEBAQHAwP8/OLgBvnFveMMfYogAfXPzDT//f25/uzqEv3t6wD73doA/NfMAPvhvEwNBgC1Ael3agD8tZYfAR0ndwD68SgABAviARUkkf7Quc8BEQADEjV5S2Mn+lgAAAAASUVORK5CYII="});
;// CONCATENATED MODULE: ./src/components/Preloader/Preloader.js




const Preloader = ({ loading  })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        style: {
            opacity: loading ? 1 : 0,
            zIndex: loading ? 9999 : -1
        },
        className: "preloader",
        children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Image, {
            className: "preloader__image",
            width: 60,
            src: loader.src,
            alt: ""
        })
    });
};
/* harmony default export */ const Preloader_Preloader = (Preloader);

// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
;// CONCATENATED MODULE: ./src/components/MobileMenu/SubNavItem.js



const SubNavItem = ({ subItem ={}  })=>{
    const { 0: expand , 1: setExpand  } = (0,external_react_.useState)(false);
    const handleExpand = (e)=>{
        e.preventDefault();
        e.stopPropagation();
        setExpand((preExpand)=>!preExpand
        );
    };
    const { href , subItems , name  } = subItem;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                href: href,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                    className: expand && (subItems === null || subItems === void 0 ? void 0 : subItems.length) ? " expanded" : "",
                    children: [
                        name,
                        (subItems === null || subItems === void 0 ? void 0 : subItems.length) && /*#__PURE__*/ jsx_runtime_.jsx("button", {
                            onClick: handleExpand,
                            "aria-label": "dropdown toggler",
                            className: expand ? "expanded" : "",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                className: "fa fa-angle-down"
                            })
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                style: {
                    display: expand ? "block" : "none"
                },
                children: subItems === null || subItems === void 0 ? void 0 : subItems.map((item)=>/*#__PURE__*/ jsx_runtime_.jsx("li", {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                            href: item.href,
                            children: item.name
                        })
                    }, item.id)
                )
            })
        ]
    });
};
/* harmony default export */ const MobileMenu_SubNavItem = (SubNavItem);

;// CONCATENATED MODULE: ./src/components/MobileMenu/NavItem.js





const NavItem_NavItem = ({ item ={}  })=>{
    const { pathname  } = (0,router_.useRouter)();
    const { 0: expand , 1: setExpand  } = (0,external_react_.useState)(false);
    const handleExpand = (e)=>{
        e.preventDefault();
        e.stopPropagation();
        setExpand((preExpand)=>!preExpand
        );
    };
    const { name , href , subNavItems  } = item;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
        className: `dropdown${pathname === href ? " current" : ""}`,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                href: href,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                    className: expand ? " expanded" : "",
                    children: [
                        name,
                        /*#__PURE__*/ jsx_runtime_.jsx("button", {
                            onClick: handleExpand,
                            "aria-label": "dropdown toggler",
                            className: expand ? "expanded" : "",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                className: "fa fa-angle-down"
                            })
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                style: {
                    display: expand ? "block" : "none"
                },
                children: subNavItems.map((subItem)=>/*#__PURE__*/ jsx_runtime_.jsx(MobileMenu_SubNavItem, {
                        subItem: subItem
                    }, subItem.id)
                )
            })
        ]
    });
};
/* harmony default export */ const MobileMenu_NavItem = (NavItem_NavItem);

;// CONCATENATED MODULE: ./src/components/MobileMenu/MobileMenu.js







const { social: MobileMenu_social , logo: MobileMenu_logo , navItems: MobileMenu_navItems  } = data_headerData;
const MobileMenu = ()=>{
    const { toggleMenu , menuStatus  } = (0,context/* useRootContext */.E)();
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: `mobile-nav__wrapper  animated fadeInLeft${menuStatus ? " expanded" : ""}`,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                onClick: ()=>toggleMenu()
                ,
                className: "mobile-nav__overlay mobile-nav__toggler"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "mobile-nav__content",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        onClick: ()=>toggleMenu()
                        ,
                        className: "mobile-nav__close mobile-nav__toggler",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                            className: "fa fa-times"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "logo-box",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                            href: "/",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                "aria-label": "logo image",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Image, {
                                    src: MobileMenu_logo.src,
                                    width: 155,
                                    alt: ""
                                })
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "mobile-nav__container",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                            className: "main-menu__list",
                            children: MobileMenu_navItems.map(({ id , ...item })=>/*#__PURE__*/ jsx_runtime_.jsx(MobileMenu_NavItem, {
                                    item: item
                                }, id)
                            )
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "mobile-nav__top",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "mobile-nav__social",
                            children: MobileMenu_social.map(({ icon , link  }, index)=>/*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    href: link,
                                    className: `fab ${icon}`
                                }, index)
                            )
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const MobileMenu_MobileMenu = (MobileMenu);

;// CONCATENATED MODULE: ./src/components/Search/Search.js



const Search = ()=>{
    const { openSearch , toggleSearch  } = (0,context/* useRootContext */.E)();
    const handleSearch = (e)=>{
        e.preventDefault();
        const formData = new FormData(e.target);
        console.log(formData.get("search"));
        toggleSearch();
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: `search-popup${openSearch ? " active" : ""}`,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                onClick: toggleSearch,
                className: "search-popup__overlay search-toggler"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "search-popup__content",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
                    onSubmit: handleSearch,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("label", {
                            htmlFor: "search",
                            className: "sr-only",
                            children: "search here"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                            type: "text",
                            id: "search",
                            name: "search",
                            placeholder: "Search Here..."
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("button", {
                            type: "submit",
                            "aria-label": "search submit",
                            className: "thm-btn",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                className: "icon-magnifying-glass"
                            })
                        })
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const Search_Search = (Search);

// EXTERNAL MODULE: ./src/assets/images/resources/footer-logo.png
var footer_logo = __webpack_require__(3289);
;// CONCATENATED MODULE: ./src/data/footerData.js

const footerData_social = [
    {
        icon: "fa-twitter",
        link: ""
    },
    {
        icon: "fa-facebook-square",
        link: ""
    },
    {
        icon: "fa-pinterest-p",
        link: ""
    },
    {
        icon: "fa-instagram",
        link: ""
    }, 
];
const footerData = {
    logo: footer_logo["default"],
    social: footerData_social,
    year: new Date().getFullYear(),
    author: "Noiu EO",
    about: "Welcome to our Trip and Tour Agency. Lorem simply text amet cing elit.",
    icons: [],
    companies: [
        {
            id: 1,
            link: "/contact",
            title: "Kontak"
        },
        {
            id: 2,
            link: "/tours",
            title: "Paket Wisata"
        },
        {
            id: 3,
            link: "/tours-list",
            title: "Paket Wisata"
        },
        {
            id: 4,
            link: "/news",
            title: "News"
        },
        {
            id: 5,
            link: "/about",
            title: "Tentang Kami"
        }, 
    ],
    explore: [
        {
            id: 1,
            link: "#",
            title: "Account"
        },
        {
            id: 2,
            link: "#",
            title: "Legal"
        },
        {
            id: 3,
            link: "#",
            title: "Contact"
        },
        {
            id: 4,
            link: "#",
            title: "Affilitate Program"
        },
        {
            id: 5,
            link: "#",
            title: "Privacy Policy"
        }, 
    ]
};
/* harmony default export */ const data_footerData = (footerData);

;// CONCATENATED MODULE: ./src/components/SiteFooter/SiteFooter.js





const { logo: SiteFooter_logo , icons: SiteFooter_icons , companies , explore , social: SiteFooter_social , year , author , about  } = data_footerData;
const SiteFooter = ()=>{
    const handleSubmit = (e)=>{
        e.preventDefault();
        const formData = new FormData(e.target);
        console.log(formData.get("email"));
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("footer", {
        className: "site-footer",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "site-footer__top",
                children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Container, {
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "site-footer__top-inner",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_react_bootstrap_.Row, {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Col, {
                                    xl: 4,
                                    lg: 6,
                                    md: 6,
                                    className: "animated fadeInUp",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "footer-widget__column footer-widget__about",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "footer-widget__about-logo",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                                    href: "/",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Image, {
                                                            // src={noiu}
                                                            src: (__webpack_require__(9603)/* ["default"].src */ .Z.src),
                                                            // src='../../assets/images/noiu.png'
                                                            // width="500" height="500"
                                                            alt: "Noiu"
                                                        })
                                                    })
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: "footer-widget__about-text",
                                                children: about
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                                                className: "footer-widget__about-contact list-unstyled",
                                                children: SiteFooter_icons.map(({ id , icon , content , subHref  })=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                className: "icon",
                                                                children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                                    className: icon
                                                                })
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                className: "text",
                                                                children: subHref ? /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                                    href: `${subHref}:${content}`,
                                                                    children: content
                                                                }) : /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                    children: content
                                                                })
                                                            })
                                                        ]
                                                    }, id)
                                                )
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Col, {
                                    xl: 2,
                                    lg: 6,
                                    md: 6,
                                    className: "animated fadeInUp",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "footer-widget__column footer-widget__company clearfix",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                                className: "footer-widget__title",
                                                children: "Company"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                                                className: "footer-widget__company-list list-unstyled",
                                                children: companies.map(({ id , link , title  })=>/*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                        children: link.includes("/") ? /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                                            href: link,
                                                            children: title
                                                        }) : /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                            target: "_blank",
                                                            rel: "noreferrer",
                                                            href: link,
                                                            children: title
                                                        })
                                                    }, id)
                                                )
                                            })
                                        ]
                                    })
                                })
                            ]
                        })
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "site-footer__bottom",
                children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Container, {
                    children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Row, {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Col, {
                            xs: 12,
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "site-footer__bottom-inner",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "site-footer__bottom-left",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "footer-widget__social",
                                            children: SiteFooter_social.map(({ icon , link  }, index)=>/*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                    href: link,
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: `fab ${icon}`
                                                    })
                                                }, index)
                                            )
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "site-footer__bottom-right",
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                            children: [
                                                "@ All Copyright ",
                                                year,
                                                ", ",
                                                /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                    href: "#",
                                                    children: author
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "site-footer__bottom-left-arrow",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            href: "#",
                                            className: "scroll-to-target scroll-to-top",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                className: "icon-right-arrow"
                                            })
                                        })
                                    })
                                ]
                            })
                        })
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const SiteFooter_SiteFooter = (SiteFooter);

;// CONCATENATED MODULE: ./src/components/Layout/Layout.js









const Layout = ({ children , pageTitle  })=>{
    const { 0: loading , 1: setLoading  } = (0,external_react_.useState)(true);
    const { menuStatus  } = (0,context/* useRootContext */.E)();
    (0,external_react_.useEffect)(()=>{
        const timeoutId = setTimeout(()=>{
            setLoading(false);
        }, 500);
        return ()=>clearTimeout(timeoutId)
        ;
    }, []);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((head_default()), {
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("title", {
                    children: [
                        pageTitle,
                        " || Noiu-EO "
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Preloader_Preloader, {
                loading: loading
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("main", {
                style: {
                    opacity: loading ? 0 : 1
                },
                className: "page-wrapper",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(Header_Header, {
                        pageTitle: pageTitle
                    }),
                    children,
                    /*#__PURE__*/ jsx_runtime_.jsx(SiteFooter_SiteFooter, {})
                ]
            }),
            menuStatus && /*#__PURE__*/ jsx_runtime_.jsx(MobileMenu_MobileMenu, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(Search_Search, {})
        ]
    });
};
/* harmony default export */ const Layout_Layout = (Layout);


/***/ }),

/***/ 2280:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "E": () => (/* binding */ useRootContext),
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

const context = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_0__.createContext)({});
const useRootContext = ()=>{
    return (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(context);
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (context);


/***/ })

};
;
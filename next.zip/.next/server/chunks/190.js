exports.id = 190;
exports.ids = [190];
exports.modules = {

/***/ 4370:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/author-1-1.619edac2.jpg","height":159,"width":170,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAcACAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABwEBAAAAAAAAAAAAAAAAAAAAAP/aAAwDAQACEAMQAAAApwP/xAAYEAACAwAAAAAAAAAAAAAAAAARIQAxUf/aAAgBAQABPwBm1gn/xAAUEQEAAAAAAAAAAAAAAAAAAAAA/9oACAECAQE/AH//xAAUEQEAAAAAAAAAAAAAAAAAAAAA/9oACAEDAQE/AH//2Q=="});

/***/ }),

/***/ 4638:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/comment-1-1.7d036b0d.png","height":166,"width":166,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAAAAADhZOFXAAAAOElEQVR42kXKMQrAIBTG4Hf/e3UqdOpW7JD83kMUxC3wpRRAih2S3oNF3ut+Mun/WltksujMKDgA5/M4PHBnLGIAAAAASUVORK5CYII="});

/***/ }),

/***/ 6142:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/comment-1-2.7d036b0d.png","height":166,"width":166,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAAAAADhZOFXAAAAOElEQVR42kXKMQrAIBTG4Hf/e3UqdOpW7JD83kMUxC3wpRRAih2S3oNF3ut+Mun/WltksujMKDgA5/M4PHBnLGIAAAAASUVORK5CYII="});

/***/ }),

/***/ 7187:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/lp-1-1.1f286307.jpg","height":65,"width":60,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAgABwMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABwEBAAAAAAAAAAAAAAAAAAAAAP/aAAwDAQACEAMQAAAApwP/xAAXEAEAAwAAAAAAAAAAAAAAAAARACJB/9oACAEBAAE/ALOE/8QAFBEBAAAAAAAAAAAAAAAAAAAAAP/aAAgBAgEBPwB//8QAFBEBAAAAAAAAAAAAAAAAAAAAAP/aAAgBAwEBPwB//9k="});

/***/ }),

/***/ 3678:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/lp-1-2.1f286307.jpg","height":65,"width":60,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAgABwMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABwEBAAAAAAAAAAAAAAAAAAAAAP/aAAwDAQACEAMQAAAApwP/xAAXEAEAAwAAAAAAAAAAAAAAAAARACJB/9oACAEBAAE/ALOE/8QAFBEBAAAAAAAAAAAAAAAAAAAAAP/aAAgBAgEBPwB//8QAFBEBAAAAAAAAAAAAAAAAAAAAAP/aAAgBAwEBPwB//9k="});

/***/ }),

/***/ 1912:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/lp-1-3.1f286307.jpg","height":65,"width":60,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAgABwMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABwEBAAAAAAAAAAAAAAAAAAAAAP/aAAwDAQACEAMQAAAApwP/xAAXEAEAAwAAAAAAAAAAAAAAAAARACJB/9oACAEBAAE/ALOE/8QAFBEBAAAAAAAAAAAAAAAAAAAAAP/aAAgBAgEBPwB//8QAFBEBAAAAAAAAAAAAAAAAAAAAAP/aAAgBAwEBPwB//9k="});

/***/ }),

/***/ 5661:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/news-details-img-1.badc88b4.jpg","height":487,"width":770,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAUACAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABwEBAAAAAAAAAAAAAAAAAAAAAP/aAAwDAQACEAMQAAAApwP/xAAXEAEAAwAAAAAAAAAAAAAAAAARAAEh/9oACAEBAAE/ADVuf//EABQRAQAAAAAAAAAAAAAAAAAAAAD/2gAIAQIBAT8Af//EABQRAQAAAAAAAAAAAAAAAAAAAAD/2gAIAQMBAT8Af//Z"});

/***/ }),

/***/ 1639:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/news-one-img-1.9b317ce1.jpg","height":487,"width":370,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAgABgMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABwEBAAAAAAAAAAAAAAAAAAAAAP/aAAwDAQACEAMQAAAApwP/xAAVEAEBAAAAAAAAAAAAAAAAAAAAIf/aAAgBAQABPwCv/8QAFBEBAAAAAAAAAAAAAAAAAAAAAP/aAAgBAgEBPwB//8QAFBEBAAAAAAAAAAAAAAAAAAAAAP/aAAgBAwEBPwB//9k="});

/***/ }),

/***/ 8784:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/news-one-img-2.9b317ce1.jpg","height":487,"width":370,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAgABgMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABwEBAAAAAAAAAAAAAAAAAAAAAP/aAAwDAQACEAMQAAAApwP/xAAVEAEBAAAAAAAAAAAAAAAAAAAAIf/aAAgBAQABPwCv/8QAFBEBAAAAAAAAAAAAAAAAAAAAAP/aAAgBAgEBPwB//8QAFBEBAAAAAAAAAAAAAAAAAAAAAP/aAAgBAwEBPwB//9k="});

/***/ }),

/***/ 1915:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/news-one-img-3.9b317ce1.jpg","height":487,"width":370,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAgABgMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABwEBAAAAAAAAAAAAAAAAAAAAAP/aAAwDAQACEAMQAAAApwP/xAAVEAEBAAAAAAAAAAAAAAAAAAAAIf/aAAgBAQABPwCv/8QAFBEBAAAAAAAAAAAAAAAAAAAAAP/aAAgBAgEBPwB//8QAFBEBAAAAAAAAAAAAAAAAAAAAAP/aAAgBAwEBPwB//9k="});

/***/ }),

/***/ 3948:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/news-page-1.9b317ce1.jpg","height":487,"width":370,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAgABgMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABwEBAAAAAAAAAAAAAAAAAAAAAP/aAAwDAQACEAMQAAAApwP/xAAVEAEBAAAAAAAAAAAAAAAAAAAAIf/aAAgBAQABPwCv/8QAFBEBAAAAAAAAAAAAAAAAAAAAAP/aAAgBAgEBPwB//8QAFBEBAAAAAAAAAAAAAAAAAAAAAP/aAAgBAwEBPwB//9k="});

/***/ }),

/***/ 1821:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/news-page-2.9b317ce1.jpg","height":487,"width":370,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAgABgMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABwEBAAAAAAAAAAAAAAAAAAAAAP/aAAwDAQACEAMQAAAApwP/xAAVEAEBAAAAAAAAAAAAAAAAAAAAIf/aAAgBAQABPwCv/8QAFBEBAAAAAAAAAAAAAAAAAAAAAP/aAAgBAgEBPwB//8QAFBEBAAAAAAAAAAAAAAAAAAAAAP/aAAgBAwEBPwB//9k="});

/***/ }),

/***/ 8374:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/news-page-3.9b317ce1.jpg","height":487,"width":370,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAgABgMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABwEBAAAAAAAAAAAAAAAAAAAAAP/aAAwDAQACEAMQAAAApwP/xAAVEAEBAAAAAAAAAAAAAAAAAAAAIf/aAAgBAQABPwCv/8QAFBEBAAAAAAAAAAAAAAAAAAAAAP/aAAgBAgEBPwB//8QAFBEBAAAAAAAAAAAAAAAAAAAAAP/aAAgBAwEBPwB//9k="});

/***/ }),

/***/ 9793:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/news-page-4.9b317ce1.jpg","height":487,"width":370,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAgABgMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABwEBAAAAAAAAAAAAAAAAAAAAAP/aAAwDAQACEAMQAAAApwP/xAAVEAEBAAAAAAAAAAAAAAAAAAAAIf/aAAgBAQABPwCv/8QAFBEBAAAAAAAAAAAAAAAAAAAAAP/aAAgBAgEBPwB//8QAFBEBAAAAAAAAAAAAAAAAAAAAAP/aAAgBAwEBPwB//9k="});

/***/ }),

/***/ 8949:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/news-page-5.9b317ce1.jpg","height":487,"width":370,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAgABgMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABwEBAAAAAAAAAAAAAAAAAAAAAP/aAAwDAQACEAMQAAAApwP/xAAVEAEBAAAAAAAAAAAAAAAAAAAAIf/aAAgBAQABPwCv/8QAFBEBAAAAAAAAAAAAAAAAAAAAAP/aAAgBAgEBPwB//8QAFBEBAAAAAAAAAAAAAAAAAAAAAP/aAAgBAwEBPwB//9k="});

/***/ }),

/***/ 3091:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/news-page-6.9b317ce1.jpg","height":487,"width":370,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAgABgMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABwEBAAAAAAAAAAAAAAAAAAAAAP/aAAwDAQACEAMQAAAApwP/xAAVEAEBAAAAAAAAAAAAAAAAAAAAIf/aAAgBAQABPwCv/8QAFBEBAAAAAAAAAAAAAAAAAAAAAP/aAAgBAgEBPwB//8QAFBEBAAAAAAAAAAAAAAAAAAAAAP/aAAgBAwEBPwB//9k="});

/***/ }),

/***/ 1190:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ NewsDetailsPage_NewsDetailsPage)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "react-bootstrap"
var external_react_bootstrap_ = __webpack_require__(358);
// EXTERNAL MODULE: ./src/data/newsDetailsPage.js
var newsDetailsPage = __webpack_require__(1894);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
;// CONCATENATED MODULE: ./src/components/NewsDetailsPage/AuthorOne.js



const AuthorOne = ({ author ={}  })=>{
    const { image , name , description  } = author;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "author-one",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "author-one__image",
                children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Image, {
                    src: image.src,
                    alt: ""
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "author-one__content",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                        children: name
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        children: description
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const NewsDetailsPage_AuthorOne = (AuthorOne);

;// CONCATENATED MODULE: ./src/components/NewsDetailsPage/CommentForm.js



const inputs = [
    "name",
    "email",
    "message"
];
const CommentForm = ()=>{
    const handleSubmit = (e)=>{
        e.preventDefault();
        const fromData = new FormData(e.target);
        const data = {};
        inputs.forEach((input)=>data[input] = fromData.get(input)
        );
        console.log(data);
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "comment-form",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                className: "comment-form__title",
                children: "Leave a Comment"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
                onSubmit: handleSubmit,
                className: "comment-one__form",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_react_bootstrap_.Row, {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Col, {
                                xl: 6,
                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "comment-form__input-box",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                        type: "text",
                                        placeholder: "Your name",
                                        name: "name"
                                    })
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Col, {
                                xl: 6,
                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "comment-form__input-box",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                        type: "email",
                                        placeholder: "Email address",
                                        name: "email"
                                    })
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Row, {
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_react_bootstrap_.Col, {
                            xl: 12,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "comment-form__input-box",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("textarea", {
                                        name: "message",
                                        placeholder: "Write Comment"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                    type: "submit",
                                    className: "thm-btn comment-form__btn",
                                    children: "Submit Comment"
                                })
                            ]
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const NewsDetailsPage_CommentForm = (CommentForm);

;// CONCATENATED MODULE: ./src/components/NewsDetailsPage/CommentOne.js



const CommentOne = ({ comments =[]  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "comment-one",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h3", {
                className: "comment-one__title",
                children: [
                    comments.length,
                    " Comments"
                ]
            }),
            comments.map(({ id , image , name , message  })=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "comment-one__single",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "comment-one__image",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Image, {
                                src: __webpack_require__(9773)(`./${image}`).default.src,
                                alt: ""
                            })
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "comment-one__content",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                    children: name
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: message
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    href: "#",
                                    className: "thm-btn comment-one__btn",
                                    children: "Reply"
                                })
                            ]
                        })
                    ]
                }, id)
            )
        ]
    });
};
/* harmony default export */ const NewsDetailsPage_CommentOne = (CommentOne);

;// CONCATENATED MODULE: ./src/components/NewsDetailsPage/NewsDetailsLeft.js








const { image: NewsDetailsLeft_image , date , author , totalComments , title , texts , tags , socials , authorData , comments ,  } = newsDetailsPage/* default */.Z;
const NewsDetailsLeft = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "news-details__left",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "news-details__img",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Image, {
                        src: NewsDetailsLeft_image.src,
                        alt: ""
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "news-one__date",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            children: date.split(" ").map((t, i)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_react_.Fragment, {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            children: t
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("br", {})
                                    ]
                                }, i)
                            )
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "news-details__content",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                        className: "list-unstyled news-one__meta",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                    href: "/news-details",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                className: "far fa-user-circle"
                                            }),
                                            author
                                        ]
                                    })
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                    href: "/news-details",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                className: "far fa-comments"
                                            }),
                                            totalComments,
                                            " Comments"
                                        ]
                                    })
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                        className: "news-details__title",
                        children: title
                    }),
                    texts.map((text, index)=>/*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: `news-details__text-${index + 1}`,
                            children: text
                        }, index)
                    )
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "news-details__bottom",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                        className: "news-details__tags",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                children: "Tags:"
                            }),
                            tags.map((tag, i)=>/*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    href: "#",
                                    children: tag
                                }, i)
                            )
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "news-details__social-list",
                        children: socials.map(({ id , icon , href  })=>/*#__PURE__*/ jsx_runtime_.jsx("a", {
                                href: href,
                                children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                    className: icon
                                })
                            }, id)
                        )
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(NewsDetailsPage_AuthorOne, {
                author: authorData
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(NewsDetailsPage_CommentOne, {
                comments: comments
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(NewsDetailsPage_CommentForm, {})
        ]
    });
};
/* harmony default export */ const NewsDetailsPage_NewsDetailsLeft = (NewsDetailsLeft);

// EXTERNAL MODULE: ./src/components/NewsDetailsPage/Sidebar.js
var Sidebar = __webpack_require__(1456);
;// CONCATENATED MODULE: ./src/components/NewsDetailsPage/NewsDetailsPage.js





const NewsDetailsPage = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        className: "news-details",
        children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Container, {
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_react_bootstrap_.Row, {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Col, {
                        xl: 8,
                        lg: 7,
                        children: /*#__PURE__*/ jsx_runtime_.jsx(NewsDetailsPage_NewsDetailsLeft, {})
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Col, {
                        xl: 4,
                        lg: 5,
                        children: /*#__PURE__*/ jsx_runtime_.jsx(Sidebar/* default */.Z, {})
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const NewsDetailsPage_NewsDetailsPage = (NewsDetailsPage);


/***/ }),

/***/ 1456:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _data_newsDetailsPage__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1894);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(358);
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_5__);






const { posts , categories , tags  } = _data_newsDetailsPage__WEBPACK_IMPORTED_MODULE_1__/* .sidebar */ .r;
const Sidebar = ()=>{
    const handleSubmit = (e)=>{
        e.preventDefault();
        const formData = new FormData(e.target);
        console.log(formData.get("search"));
    };
    const { 0: data , 1: setData  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)("");
    const getBlog = async ()=>{
        const response = await axios__WEBPACK_IMPORTED_MODULE_5___default().get('https://api.noiu-eo.com/v1/blog/posts?page=1&perPage=4').then((result)=>{
            // console.log("data api", result.data);
            setData(result.data.data);
            console.log(result.data.data);
        }).catch((err)=>{
            console.log("error", err);
        });
    };
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        getBlog();
    }, []);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "sidebar",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "sidebar__single sidebar__post",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                    className: "sidebar__title",
                    children: "Recent News"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                    className: "sidebar__post-list list-unstyled",
                    children: data && data.map(({ _id , title , image , comments  })=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "sidebar__post-image",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_4__.Image, {
                                        src: `https://api.noiu-eo.com/${image}`,
                                        alt: ""
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "sidebar__post-content",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_2__["default"], {
                                            href: `/news-detail/${_id}`,
                                            children: title
                                        })
                                    })
                                })
                            ]
                        }, _id)
                    )
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Sidebar);


/***/ }),

/***/ 1894:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "r": () => (/* binding */ sidebar),
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _images_blog_author_1_1_jpg__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4370);
/* harmony import */ var _images_blog_news_details_img_1_jpg__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5661);


const text1 = " Lorem ipsum available isn but the majority have suffered alteratin in some or form injected. Lorem Ipsum. Proin gravida nibh vel velit auctor aliqueenean sollicitudin, lorem quis bibendum auctor, nisi elit consequat ipsum, nec sagittis sem nibh id elit. vulputate cursus a sit amet mauris. Morbi accumsan ipsum veliam nec tellus a odio tincidunt auctor.";
const text2 = "There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some injected or words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable.";
const text3 = "Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting.";
const text4 = "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into unchanged. Lorem Ipsum passages publishing.";
const newsDetailsPage = {
    image: _images_blog_news_details_img_1_jpg__WEBPACK_IMPORTED_MODULE_1__["default"],
    date: "28 Aug",
    author: "Admin",
    totalComments: 2,
    title: "Things to See and Do When Visiting Japan",
    texts: [
        text1,
        text2,
        text3,
        text4
    ],
    tags: [
        "Traveling",
        "Adventure"
    ],
    socials: [
        {
            id: 1,
            icon: "fab fa-twitter",
            href: "#"
        },
        {
            id: 2,
            icon: "fab fa-facebook",
            href: "#"
        },
        {
            id: 3,
            icon: "fab fa-instagram",
            href: "#"
        },
        {
            id: 4,
            icon: "fab fa-dribbble",
            href: "#"
        }, 
    ],
    authorData: {
        image: _images_blog_author_1_1_jpg__WEBPACK_IMPORTED_MODULE_0__["default"],
        name: "Christine Eve",
        description: "It has survived not only five centuries, but also the leap into electronic typesetting, remaining unchanged. It was popularised in the sheets containing."
    },
    comments: [
        {
            id: 1,
            image: "comment-1-1.png",
            name: "Kevin Martin",
            message: "It has survived not only five centuries, but also the leap into electronic typesetting unchanged. It was popularised in the sheets containing lorem ipsum is simply free text available in the martket to use now."
        },
        {
            id: 2,
            image: "comment-1-2.png",
            name: "Sarah Albert",
            message: "It has survived not only five centuries, but also the leap into electronic typesetting unchanged. It was popularised in the sheets containing lorem ipsum is simply free text available in the martket to use now."
        }, 
    ]
};
const sidebar = {
    posts: [
        {
            id: 1,
            image: "lp-1-1.jpg",
            comments: 2,
            title: "Travel Most Beautiful Places in the World"
        },
        {
            id: 2,
            image: "lp-1-2.jpg",
            comments: 2,
            title: "Travel Most Beautiful Places in the World"
        },
        {
            id: 3,
            image: "lp-1-3.jpg",
            comments: 2,
            title: "Travel Most Beautiful Places in the World"
        }, 
    ],
    categories: [
        "Trip & Tours",
        "Traveling",
        "Adventures",
        "National Parks",
        "Beaches and Sea", 
    ],
    tags: [
        "Traveling",
        "Adventure",
        "Beach",
        "Parks",
        "Museum",
        "Tourisms"
    ]
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (newsDetailsPage);


/***/ }),

/***/ 9773:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var map = {
	"./author-1-1.jpg": 4370,
	"./comment-1-1.png": 4638,
	"./comment-1-2.png": 6142,
	"./lp-1-1.jpg": 7187,
	"./lp-1-2.jpg": 3678,
	"./lp-1-3.jpg": 1912,
	"./news-details-img-1.jpg": 5661,
	"./news-one-img-1.jpg": 1639,
	"./news-one-img-2.jpg": 8784,
	"./news-one-img-3.jpg": 1915,
	"./news-page-1.jpg": 3948,
	"./news-page-2.jpg": 1821,
	"./news-page-3.jpg": 8374,
	"./news-page-4.jpg": 9793,
	"./news-page-5.jpg": 8949,
	"./news-page-6.jpg": 3091
};


function webpackContext(req) {
	var id = webpackContextResolve(req);
	return __webpack_require__(id);
}
function webpackContextResolve(req) {
	if(!__webpack_require__.o(map, req)) {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	}
	return map[req];
}
webpackContext.keys = function webpackContextKeys() {
	return Object.keys(map);
};
webpackContext.resolve = webpackContextResolve;
module.exports = webpackContext;
webpackContext.id = 9773;

/***/ })

};
;
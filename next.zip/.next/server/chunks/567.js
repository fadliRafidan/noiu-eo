"use strict";
exports.id = 567;
exports.ids = [567];
exports.modules = {

/***/ 4258:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(358);
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap__WEBPACK_IMPORTED_MODULE_1__);


const JarallaxImage = ({ className ="" , alt ="" , ...props })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_1__.Image, {
        className: `jarallax-img ${className}`,
        alt: alt,
        ...props
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (JarallaxImage);


/***/ }),

/***/ 4430:
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {


// UNUSED EXPORTS: default

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ./src/assets/images/shapes/about-page-testimonial-map.png
/* harmony default export */ const about_page_testimonial_map = ({"src":"/_next/static/media/about-page-testimonial-map.39ea9f09.png","height":560,"width":1157,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAECAYAAACzzX7wAAAAYklEQVR42i2MIQuAUAyEl002DYovGAS7Gu3CA5vR6J9+a1t4+xPeYIOP293GkQkfpnyDBCaTksFn6soNwSxggyGQq/KLxwec5FOlOHsVXqEzDldk3jgSqpwBQR97G9qZcvoBHllYDUqVWQYAAAAASUVORK5CYII="});
;// CONCATENATED MODULE: ./src/assets/images/shapes/testimonial-one-shape-2.png
/* harmony default export */ const testimonial_one_shape_2 = ({"src":"/_next/static/media/testimonial-one-shape-2.9107e0fe.png","height":246,"width":216,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAcAAAAICAMAAAAC2hU0AAAAaVBMVEXr5t7r5t3q5t7r5d7r5d3q5d7q5d0AAADr5t3r5d3r5t7r5d7r5t3r5d7r5t3r5t7r5d3r5t7r5t3r5t7q5t3r5d7r5d7r5t7r5t7q5d3r5t7q5d3r5d3r5t7r5t7r5t7r5t3q5t3r5t2srsduAAAAI3RSTlMAAAAAAAAAAAEBAgMEBggKCg0ODxAQFBkaGhsfJCwuMDQ2N1/cSt8AAAA8SURBVHjaBYCFEcAgDACfBkKh7q77D8khQZtrvcnZnv9doDy+cwbTFnavFDeMWOeIU01A6KNBgU5sJt4nZw8ClhDFkjcAAAAASUVORK5CYII="});
;// CONCATENATED MODULE: ./src/assets/images/shapes/testimonial-one-shape-3.png
/* harmony default export */ const testimonial_one_shape_3 = ({"src":"/_next/static/media/testimonial-one-shape-3.a9af98b7.png","height":27,"width":63,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAADCAYAAACuyE5IAAAARElEQVR42mN4/eye1Ound1NfP703B0jzMeACQAWuQLwWqMgPSAcAaV2gZiYGIMEI5LCCFT276w6UDANiM6C4z+un91wAqfAx38LADkoAAAAASUVORK5CYII="});
;// CONCATENATED MODULE: ./src/data/testimonialOne.js



const testimonialOne = {
    bg: about_page_testimonial_map,
    shape1: testimonial_one_shape_2,
    shape2: testimonial_one_shape_3,
    tagline: "Testimonials & reviews",
    title: "What They’re Saying",
    testimonials: [
        {
            id: 1,
            image: "testimonial-one-img-1.png",
            review: 5,
            description: "This is due to their best service, pricing and customer support. It’s throughly refresing to such a personal touch. Duis aute irure lupsum reprehenderit.",
            client: {
                name: "Shirley Smith",
                role: "Customer"
            }
        },
        {
            id: 2,
            image: "testimonial-one-img-2.png",
            review: 5,
            description: "This is due to their best service, pricing and customer support. It’s throughly refresing to such a personal touch. Duis aute irure lupsum reprehenderit.",
            client: {
                name: "Kevin Martin",
                role: "Customer"
            }
        },
        {
            id: 3,
            image: "testimonial-one-img-3.png",
            review: 5,
            description: "This is due to their best service, pricing and customer support. It’s throughly refresing to such a personal touch. Duis aute irure lupsum reprehenderit.",
            client: {
                name: "Jessica Brown",
                role: "Customer"
            }
        },
        {
            id: 4,
            image: "testimonial-one-img-1.png",
            review: 5,
            description: "This is due to their best service, pricing and customer support. It’s throughly refresing to such a personal touch. Duis aute irure lupsum reprehenderit.",
            client: {
                name: "Shirley Smith",
                role: "Customer"
            }
        },
        {
            id: 5,
            image: "testimonial-one-img-2.png",
            review: 5,
            description: "This is due to their best service, pricing and customer support. It’s throughly refresing to such a personal touch. Duis aute irure lupsum reprehenderit.",
            client: {
                name: "Kevin Martin",
                role: "Customer"
            }
        },
        {
            id: 6,
            image: "testimonial-one-img-3.png",
            review: 5,
            description: "This is due to their best service, pricing and customer support. It’s throughly refresing to such a personal touch. Duis aute irure lupsum reprehenderit.",
            client: {
                name: "Jessica Brown",
                role: "Customer"
            }
        },
        {
            id: 7,
            image: "testimonial-one-img-1.png",
            review: 5,
            description: "This is due to their best service, pricing and customer support. It’s throughly refresing to such a personal touch. Duis aute irure lupsum reprehenderit.",
            client: {
                name: "Shirley Smith",
                role: "Customer"
            }
        },
        {
            id: 8,
            image: "testimonial-one-img-2.png",
            review: 5,
            description: "This is due to their best service, pricing and customer support. It’s throughly refresing to such a personal touch. Duis aute irure lupsum reprehenderit.",
            client: {
                name: "Kevin Martin",
                role: "Customer"
            }
        },
        {
            id: 9,
            image: "testimonial-one-img-3.png",
            review: 5,
            description: "This is due to their best service, pricing and customer support. It’s throughly refresing to such a personal touch. Duis aute irure lupsum reprehenderit.",
            client: {
                name: "Jessica Brown",
                role: "Customer"
            }
        }, 
    ]
};
/* harmony default export */ const data_testimonialOne = (testimonialOne);

// EXTERNAL MODULE: ./node_modules/next/dynamic.js
var dynamic = __webpack_require__(5152);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "react-bootstrap"
var external_react_bootstrap_ = __webpack_require__(358);
// EXTERNAL MODULE: external "axios"
var external_axios_ = __webpack_require__(2167);
;// CONCATENATED MODULE: ./src/components/TestimonialOne/SingleTestimonial.js




const SingleTestimonial_SingleTestimonial = ({ testimonial  })=>{
    const { 0: data , 1: setData  } = useState([]);
    const getBlog = async ()=>{
        const response = await axios.get('https://api.noiu-eo.com/v1/testimoni/posts?page=1&perPage=10').then((result)=>{
            // console.log("data api", result.data);
            setData(result.data.data);
            console.log(result.data.data);
        }).catch((err)=>{
            console.log("error", err);
        });
    };
    useEffect(()=>{
        getBlog();
    }, []);
    return /*#__PURE__*/ _jsx(_Fragment, {
        children: data && data.map((row)=>/*#__PURE__*/ _jsx("div", {
                children: /*#__PURE__*/ _jsxs("div", {
                    style: {
                        userSelect: "none"
                    },
                    className: "testimonial-one__single",
                    children: [
                        /*#__PURE__*/ _jsx("div", {
                            className: "testimonial-one__img",
                            children: /*#__PURE__*/ _jsx(Image, {
                                src: `https://api.noiu-eo.com/${row.image}`,
                                alt: ""
                            })
                        }),
                        /*#__PURE__*/ _jsxs("div", {
                            className: "testimonail-one__content",
                            children: [
                                /*#__PURE__*/ _jsx("div", {
                                    className: "testimonial-one__top-revivew-box",
                                    children: Array.from(Array(row.rating)).map((_, i)=>/*#__PURE__*/ _jsx("i", {
                                            className: "fa fa-star"
                                        }, i)
                                    )
                                }),
                                /*#__PURE__*/ _jsx("p", {
                                    className: "testimonial-one__text",
                                    children: row.destinasi
                                }),
                                /*#__PURE__*/ _jsxs("div", {
                                    className: "testimonial-one__client-info",
                                    children: [
                                        /*#__PURE__*/ _jsx("h3", {
                                            className: "testimonial-one__client-name",
                                            children: row.title
                                        }),
                                        /*#__PURE__*/ _jsx("p", {
                                            className: "testimonial-one__client-title",
                                            children: row.body
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                })
            }, row._id)
        )
    });
};
/* harmony default export */ const TestimonialOne_SingleTestimonial = ((/* unused pure expression or super */ null && (SingleTestimonial_SingleTestimonial)));

;// CONCATENATED MODULE: ./src/components/TestimonialOne/TestimonialOne.js






const TinySlider = (0,dynamic["default"])(null, {
    loadableGenerated: {
        modules: [
            "../components/TestimonialOne/TestimonialOne.js -> " + "tiny-slider-react"
        ]
    },
    ssr: false
});
const settings = {
    lazyload: true,
    nav: true,
    navPosition: "bottom",
    mouseDrag: true,
    items: 1,
    autoplay: true,
    autoHeight: true,
    controls: false,
    gutter: 0,
    autoplayButton: false,
    autoplayButtonOutput: false,
    responsive: {
        768: {
            items: 2,
            gutter: 30
        },
        1200: {
            items: 3,
            gutter: 30
        }
    }
};
const { shape1 , shape2 , tagline , title , testimonials , bg  } = data_testimonialOne;
const TestimonialOne = ({ aboutPage =false  })=>{
    return /*#__PURE__*/ _jsxs("section", {
        className: aboutPage ? "testimonial-one about-page-testimonial" : "testimonial-one",
        children: [
            aboutPage ? /*#__PURE__*/ _jsx("div", {
                className: "about-page-testimonial-map",
                style: {
                    backgroundImage: ` url(${bg.src})`
                }
            }) : /*#__PURE__*/ _jsxs(_Fragment, {
                children: [
                    /*#__PURE__*/ _jsx("div", {
                        className: "testimonial-one-shape-2 float-bob-y",
                        children: /*#__PURE__*/ _jsx(Image, {
                            src: shape1.src,
                            alt: ""
                        })
                    }),
                    /*#__PURE__*/ _jsx("div", {
                        className: "testimonial-one-shape-3 animated slideInRight",
                        children: /*#__PURE__*/ _jsx(Image, {
                            src: shape2.src,
                            alt: ""
                        })
                    })
                ]
            }),
            /*#__PURE__*/ _jsxs(Container, {
                children: [
                    /*#__PURE__*/ _jsxs("div", {
                        className: "section-title text-center",
                        children: [
                            /*#__PURE__*/ _jsx("span", {
                                className: "section-title__tagline",
                                children: tagline
                            }),
                            /*#__PURE__*/ _jsx("h2", {
                                className: "section-title__title",
                                children: title
                            })
                        ]
                    }),
                    /*#__PURE__*/ _jsx(Row, {
                        children: /*#__PURE__*/ _jsx(Col, {
                            xl: 12,
                            children: /*#__PURE__*/ _jsx("div", {
                                className: "testimonial-one__carousel",
                                children: /*#__PURE__*/ _jsx(TinySlider, {
                                    settings: settings,
                                    children: /*#__PURE__*/ _jsx(SingleTestimonial, {})
                                })
                            })
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const TestimonialOne_TestimonialOne = ((/* unused pure expression or super */ null && (TestimonialOne)));


/***/ }),

/***/ 9821:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_modal_video__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9485);
/* harmony import */ var react_modal_video__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_modal_video__WEBPACK_IMPORTED_MODULE_2__);




const VideoModal = ({ isOpen , setOpen , id  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children:  false && /*#__PURE__*/ 0
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (VideoModal);


/***/ })

};
;
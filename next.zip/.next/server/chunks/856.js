"use strict";
exports.id = 856;
exports.ids = [856];
exports.modules = {

/***/ 7776:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _data_mainSliderTwoData__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5857);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var swiper__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3877);
/* harmony import */ var swiper_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3015);
/* harmony import */ var _SingleSlide__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(427);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([swiper__WEBPACK_IMPORTED_MODULE_3__, swiper_react__WEBPACK_IMPORTED_MODULE_4__, _SingleSlide__WEBPACK_IMPORTED_MODULE_5__]);
([swiper__WEBPACK_IMPORTED_MODULE_3__, swiper_react__WEBPACK_IMPORTED_MODULE_4__, _SingleSlide__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






swiper__WEBPACK_IMPORTED_MODULE_3__["default"].use([
    swiper__WEBPACK_IMPORTED_MODULE_3__.Autoplay,
    swiper__WEBPACK_IMPORTED_MODULE_3__.Navigation,
    swiper__WEBPACK_IMPORTED_MODULE_3__.EffectFade
]);
const mainSlideOptions = {
    slidesPerView: 1,
    loop: true,
    effect: "fade",
    navigation: {
        nextEl: "#main-slider__swiper-button-next",
        prevEl: "#main-slider__swiper-button-prev",
        clickable: true
    },
    autoplay: {
        delay: 5000
    }
};
const MainSliderTwo = ()=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
        className: "main-slider tour-details-slider",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(swiper_react__WEBPACK_IMPORTED_MODULE_4__.Swiper, {
            className: "thm-swiper__slider",
            ...mainSlideOptions,
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "swiper-wrapper",
                    children: _data_mainSliderTwoData__WEBPACK_IMPORTED_MODULE_1__/* ["default"].map */ .Z.map((slide)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_SingleSlide__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                            slide: slide
                        }, slide.id)
                    )
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "main-slider-nav",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            id: "main-slider__swiper-button-prev",
                            className: "main-slider-button-prev",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "icon-right-arrow"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            id: "main-slider__swiper-button-next",
                            className: "main-slider-button-next",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "icon-right-arrow"
                            })
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MainSliderTwo);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 427:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(358);
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var swiper_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3015);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([swiper_react__WEBPACK_IMPORTED_MODULE_3__]);
swiper_react__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




const SingleSlide = ({ slide ={}  })=>{
    const { bg  } = slide;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(swiper_react__WEBPACK_IMPORTED_MODULE_3__.SwiperSlide, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "image-layer",
                style: {
                    backgroundImage: `url(${bg.src})`
                }
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Container, {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "swiper-slide-inner",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "tour-details-slider_icon",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                href: "#",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                    className: "fab fa-youtube"
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                href: "#",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                    className: "fa fa-heart"
                                })
                            })
                        ]
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SingleSlide);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 681:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ TourDetails_TourDetailsPage)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./src/data/tourDetailsPage.js
const tourDetailsOne = {
    title: "National Park 2 Days Tour",
    rate: 870,
    duration: "3 Days",
    minAge: "12 +",
    tourType: "Adventure, Fun",
    location: "Los Angeles",
    date: "2 days ago",
    superb: "8.0"
};
const tourDetailsLeft = {
    superb: "7.0",
    overview: "Lorem ipsum available isn but the majority have suffered alteratin in some or form injected simply free text used by copytyping refreshing. Neque porro est qui dolorem ipsum quia quaed inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Lorem ipsum is simply free text used by copytyping refreshing. Neque porro est qui dolorem ipsum quia quaed inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Aelltes port lacus quis enim var sed efficitur turpis gilla sed sit amet finibus eros.",
    overviewList: [
        "Pick and Drop Services",
        "1 Meal Per Day",
        "Cruise Dinner & Music Event",
        "Visit 7 Best Places in the City With Group",
        "Additional Services",
        "Insurance",
        "Food & Drinks",
        "Tickets", 
    ],
    faq: [
        {
            id: 1,
            title: "Arrive South Africa Forest",
            text: "There are many variations of passages of available but majority have alteration in some by inject humour or random words. Lorem ipsum dolor sit amet, error insolens reprimique no quo, ea pri verterem phaedr vel ea iisque aliquam.",
            lists: [
                "Free Drinks",
                "Awesome Breakfast",
                "5 Star Accommodation"
            ]
        },
        {
            id: 2,
            title: "Lunch Inside of Forest & Adventure",
            text: "There are many variations of passages of available but majority have alteration in some by inject humour or random words. Lorem ipsum dolor sit amet, error insolens reprimique no quo, ea pri verterem phaedr vel ea iisque aliquam.",
            lists: [
                "Free Drinks",
                "Awesome Breakfast",
                "5 Star Accommodation"
            ]
        },
        {
            id: 3,
            title: "Depart from South Africa",
            text: "There are many variations of passages of available but majority have alteration in some by inject humour or random words. Lorem ipsum dolor sit amet, error insolens reprimique no quo, ea pri verterem phaedr vel ea iisque aliquam.",
            lists: [
                "Free Drinks",
                "Awesome Breakfast",
                "5 Star Accommodation"
            ]
        }, 
    ],
    reviewScore: [
        {
            id: 1,
            title: "Services",
            percent: 50
        },
        {
            id: 2,
            title: "Locations",
            percent: 87
        },
        {
            id: 3,
            title: "Amenities",
            percent: 77
        },
        {
            id: 4,
            title: "Prices",
            percent: 69
        },
        {
            id: 5,
            title: "Food",
            percent: 40
        }, 
    ],
    comments: [
        {
            id: 1,
            image: "tour-review-1-1.png",
            name: "Mike Hardson",
            date: "06 Jun, 2021",
            title: "Fun Was To Discover This",
            message: "Lorem ipsum is simply free text used by copytyping refreshing. Neque porro est qui dolorem ipsum quia quaed inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo var lla sed sit amet finibus eros.",
            services: 2,
            locations: 2,
            amenities: 2,
            prices: 2,
            food: 2
        },
        {
            id: 2,
            image: "tour-review-1-2.png",
            name: "Jessica Brown",
            date: "06 Jun, 2021",
            title: "Fun Was To Discover This",
            message: "Lorem ipsum is simply free text used by copytyping refreshing. Neque porro est qui dolorem ipsum quia quaed inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo var lla sed sit amet finibus eros.",
            services: 2,
            locations: 2,
            amenities: 2,
            prices: 2,
            food: 2
        }, 
    ],
    reviews: [
        {
            id: 1,
            title: "Services",
            star: 2
        },
        {
            id: 2,
            title: "Locations",
            star: 2
        },
        {
            id: 3,
            title: "Amenities",
            star: 2
        },
        {
            id: 4,
            title: "Prices",
            star: 2
        },
        {
            id: 5,
            title: "Food",
            star: 2
        }, 
    ]
};
const tourDetailsSidebar = [
    {
        id: 1,
        image: "td-img-1.jpg",
        price: "380",
        title: "Africa 2 Days Tour",
        location: "Los Angeles"
    },
    {
        id: 2,
        image: "td-img-2.jpg",
        price: "380",
        title: "Africa 2 Days Tour",
        location: "Los Angeles"
    },
    {
        id: 3,
        image: "td-img-3.jpg",
        price: "380",
        title: "Africa 2 Days Tour",
        location: "Los Angeles"
    }, 
];

// EXTERNAL MODULE: external "react-bootstrap"
var external_react_bootstrap_ = __webpack_require__(358);
;// CONCATENATED MODULE: ./src/components/TourDetails/TourDetailsOne.js




const { title , rate , duration , minAge , tourType , location: TourDetailsOne_location , date , superb  } = tourDetailsOne;
const TourDetailsOne = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        className: "tour-details",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "tour-details__top",
                children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Container, {
                    children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Row, {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Col, {
                            xl: 12,
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "tour-details__top-inner",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "tour-details__top-left",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                                className: "tour-details__top-title",
                                                children: title
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                                className: "tour-details__top-rate",
                                                children: [
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                        children: [
                                                            "$",
                                                            rate
                                                        ]
                                                    }),
                                                    " / Per Person"
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "tour-details__top-right",
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                            className: "list-unstyled tour-details__top-list",
                                            children: [
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                            className: "icon",
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                className: "icon-clock"
                                                            })
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                            className: "text",
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                    children: "Duration"
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                                                                    children: duration
                                                                })
                                                            ]
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                            className: "icon",
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                className: "icon-user"
                                                            })
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                            className: "text",
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                    children: "Min Age"
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                                                                    children: minAge
                                                                })
                                                            ]
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                            className: "icon",
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                className: "icon-plane"
                                                            })
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                            className: "text",
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                    children: "Tour Type"
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                                                                    children: tourType
                                                                })
                                                            ]
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                            className: "icon",
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                className: "icon-place"
                                                            })
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                            className: "text",
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                    children: "Location"
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                                                                    children: TourDetailsOne_location
                                                                })
                                                            ]
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    })
                                ]
                            })
                        })
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "tour-details__bottom",
                children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Container, {
                    children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Row, {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Col, {
                            xl: 12,
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "tour-details__bottom-inner",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "tour-details__bottom-left",
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                            className: "list-unstyled tour-details__bottom-list",
                                            children: [
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                            className: "icon",
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                className: "icon-clock"
                                                            })
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                            className: "text",
                                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                                                children: [
                                                                    "Posted ",
                                                                    date
                                                                ]
                                                            })
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                            className: "icon",
                                                            children: Array.from(Array(5)).map((_, i)=>/*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                                    className: "fa fa-star"
                                                                }, i)
                                                            )
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                            className: "text",
                                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                                                children: [
                                                                    superb,
                                                                    " Superb"
                                                                ]
                                                            })
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "tour-details__bottom-right",
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                            href: "#",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                    className: "fas fa-share"
                                                }),
                                                "share"
                                            ]
                                        })
                                    })
                                ]
                            })
                        })
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const TourDetails_TourDetailsOne = (TourDetailsOne);

// EXTERNAL MODULE: ./src/components/PopularTours/SingleTour.js
var PopularTours_SingleTour = __webpack_require__(8856);
// EXTERNAL MODULE: ./src/data/popularTours.js
var data_popularTours = __webpack_require__(1095);
;// CONCATENATED MODULE: ./src/components/TourDetails/ReviewForm.js



const ReviewForm_ReviewForm = ({ reviews =[]  })=>{
    const handleSubmit = (e)=>{
        e.preventDefault();
    };
    return /*#__PURE__*/ _jsxs("div", {
        className: "tour-details__review-form",
        children: [
            /*#__PURE__*/ _jsx("h3", {
                className: "tour-details-two__title",
                children: "Write a Review"
            }),
            /*#__PURE__*/ _jsxs(Row, {
                children: [
                    /*#__PURE__*/ _jsx(Col, {
                        xl: 6,
                        children: /*#__PURE__*/ _jsx("div", {
                            className: "tour-details__review-form-left",
                            children: /*#__PURE__*/ _jsxs("form", {
                                onSubmit: handleSubmit,
                                className: "tour-details__review-form",
                                children: [
                                    /*#__PURE__*/ _jsx("div", {
                                        className: "tour-details__review-form-input",
                                        children: /*#__PURE__*/ _jsx("input", {
                                            type: "text",
                                            placeholder: "Your Name",
                                            name: "name"
                                        })
                                    }),
                                    /*#__PURE__*/ _jsx("div", {
                                        className: "tour-details__review-form-input",
                                        children: /*#__PURE__*/ _jsx("input", {
                                            type: "email",
                                            placeholder: "Email Address",
                                            name: "email"
                                        })
                                    }),
                                    /*#__PURE__*/ _jsx("div", {
                                        className: "tour-details__review-form-input",
                                        children: /*#__PURE__*/ _jsx("input", {
                                            type: "text",
                                            placeholder: "Review Title",
                                            name: "review"
                                        })
                                    })
                                ]
                            })
                        })
                    }),
                    /*#__PURE__*/ _jsx(Col, {
                        xl: 6,
                        children: /*#__PURE__*/ _jsx("div", {
                            className: "tour-details__review-form-rate",
                            children: reviews.map(({ id , title , star  })=>/*#__PURE__*/ _jsxs("div", {
                                    className: "tour-details__review-form-rate-single",
                                    children: [
                                        /*#__PURE__*/ _jsx("div", {
                                            className: "tour-details__review-form-rate-left",
                                            children: /*#__PURE__*/ _jsx("span", {
                                                children: title
                                            })
                                        }),
                                        /*#__PURE__*/ _jsx("div", {
                                            className: "tour-details__review-form-rate-right",
                                            children: Array.from(Array(5)).map((_, i)=>/*#__PURE__*/ _jsx("i", {
                                                    className: `fa fa-star${i < star ? " active" : ""}`
                                                }, i)
                                            )
                                        })
                                    ]
                                }, id)
                            )
                        })
                    })
                ]
            }),
            /*#__PURE__*/ _jsx("div", {
                className: "tour-details__review-form-textarea",
                children: /*#__PURE__*/ _jsxs("form", {
                    onSubmit: handleSubmit,
                    children: [
                        /*#__PURE__*/ _jsx("textarea", {
                            placeholder: "Write Comment"
                        }),
                        /*#__PURE__*/ _jsx("button", {
                            type: "submit",
                            className: "thm-btn tour-details__review-form-btn",
                            children: "Submit Review"
                        })
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const TourDetails_ReviewForm = ((/* unused pure expression or super */ null && (ReviewForm_ReviewForm)));

// EXTERNAL MODULE: external "react-visibility-sensor"
var external_react_visibility_sensor_ = __webpack_require__(6882);
;// CONCATENATED MODULE: ./src/components/TourDetails/ReviewScoreBar.js



const ReviewScoreBar_ReviewScoreBar = ({ review ={}  })=>{
    const { 0: countStart , 1: setCountStart  } = useState(false);
    const onVisibilityChange = (isVisible)=>{
        if (isVisible) {
            setCountStart(true);
        }
    };
    const { percent , title  } = review;
    return /*#__PURE__*/ _jsx(ReactVisibilitySensor, {
        offset: {
            top: 10
        },
        delayedCall: true,
        onChange: onVisibilityChange,
        children: /*#__PURE__*/ _jsxs("div", {
            className: "tour-details__review-score__bar",
            children: [
                /*#__PURE__*/ _jsxs("div", {
                    className: "tour-details__review-score__bar-top",
                    children: [
                        /*#__PURE__*/ _jsx("h3", {
                            children: title
                        }),
                        /*#__PURE__*/ _jsxs("p", {
                            children: [
                                countStart ? percent : 0,
                                "%"
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ _jsx("div", {
                    className: "tour-details__review-score__bar-line",
                    children: /*#__PURE__*/ _jsx("span", {
                        className: "animated slideInLeft",
                        style: {
                            width: `${countStart ? percent : 0}%`
                        }
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const TourDetails_ReviewScoreBar = ((/* unused pure expression or super */ null && (ReviewScoreBar_ReviewScoreBar)));

;// CONCATENATED MODULE: ./src/components/TourDetails/SingleComment.js



const SingleComment_SingleComment = ({ comment ={}  })=>{
    const { image , name , date , title , message , services , locations , amenities , prices , food ,  } = comment;
    return /*#__PURE__*/ _jsxs("div", {
        className: "tour-details__review-comment-single",
        children: [
            /*#__PURE__*/ _jsxs("div", {
                className: "tour-details__review-comment-top",
                children: [
                    /*#__PURE__*/ _jsx("div", {
                        className: "tour-details__review-comment-top-img",
                        children: /*#__PURE__*/ _jsx(Image, {
                            src: __webpack_require__(7516)(`./${image}`).default.src,
                            alt: ""
                        })
                    }),
                    /*#__PURE__*/ _jsxs("div", {
                        className: "tour-details__review-comment-top-content",
                        children: [
                            /*#__PURE__*/ _jsx("h3", {
                                children: name
                            }),
                            /*#__PURE__*/ _jsx("p", {
                                children: date
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ _jsxs("div", {
                className: "tour-details__review-comment-content",
                children: [
                    /*#__PURE__*/ _jsx("h3", {
                        children: title
                    }),
                    /*#__PURE__*/ _jsx("p", {
                        children: message
                    })
                ]
            }),
            /*#__PURE__*/ _jsx("div", {
                className: "tour-details__review-form-stars",
                children: /*#__PURE__*/ _jsxs(Row, {
                    children: [
                        /*#__PURE__*/ _jsxs(Col, {
                            md: 4,
                            children: [
                                /*#__PURE__*/ _jsxs("p", {
                                    children: [
                                        /*#__PURE__*/ _jsx("span", {
                                            children: "Services"
                                        }),
                                        Array.from(Array(5)).map((_, i)=>/*#__PURE__*/ _jsx("i", {
                                                className: `fa fa-star${i < services ? " active" : ""}`
                                            }, i)
                                        )
                                    ]
                                }),
                                /*#__PURE__*/ _jsxs("p", {
                                    children: [
                                        /*#__PURE__*/ _jsx("span", {
                                            children: "Locations"
                                        }),
                                        Array.from(Array(5)).map((_, i)=>/*#__PURE__*/ _jsx("i", {
                                                className: `fa fa-star${i < locations ? " active" : ""}`
                                            }, i)
                                        )
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ _jsxs(Col, {
                            md: 4,
                            children: [
                                /*#__PURE__*/ _jsxs("p", {
                                    children: [
                                        /*#__PURE__*/ _jsx("span", {
                                            children: "Amenities"
                                        }),
                                        Array.from(Array(5)).map((_, i)=>/*#__PURE__*/ _jsx("i", {
                                                className: `fa fa-star${i < amenities ? " active" : ""}`
                                            }, i)
                                        )
                                    ]
                                }),
                                /*#__PURE__*/ _jsxs("p", {
                                    children: [
                                        /*#__PURE__*/ _jsx("span", {
                                            children: "Prices"
                                        }),
                                        Array.from(Array(5)).map((_, i)=>/*#__PURE__*/ _jsx("i", {
                                                className: `fa fa-star${i < prices ? " active" : ""}`
                                            }, i)
                                        )
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ _jsx(Col, {
                            md: 4,
                            children: /*#__PURE__*/ _jsxs("p", {
                                children: [
                                    /*#__PURE__*/ _jsx("span", {
                                        children: "Food"
                                    }),
                                    Array.from(Array(5)).map((_, i)=>/*#__PURE__*/ _jsx("i", {
                                            className: `fa fa-star${i < food ? " active" : ""}`
                                        }, i)
                                    )
                                ]
                            })
                        })
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const TourDetails_SingleComment = ((/* unused pure expression or super */ null && (SingleComment_SingleComment)));

;// CONCATENATED MODULE: ./src/components/TourDetails/TourDetailsLeft.js









const { overview , overviewList , faq , superb: TourDetailsLeft_superb , reviewScore , comments , reviews  } = tourDetailsLeft;
const TourDetailsLeft_TourDetailsLeft = ()=>{
    const { 0: active , 1: setActive  } = useState(1);
    return /*#__PURE__*/ _jsxs("div", {
        className: "tour-details-two__left",
        children: [
            /*#__PURE__*/ _jsxs("div", {
                className: "tour-details-two__overview",
                children: [
                    /*#__PURE__*/ _jsx("h3", {
                        className: "tour-details-two__title",
                        children: "Overview"
                    }),
                    /*#__PURE__*/ _jsx("p", {
                        className: "tour-details-two__overview-text",
                        children: overview
                    }),
                    /*#__PURE__*/ _jsxs("div", {
                        className: "tour-details-two__overview-bottom",
                        children: [
                            /*#__PURE__*/ _jsx("h3", {
                                className: "tour-details-two-overview__title",
                                children: "Included/Exclude"
                            }),
                            /*#__PURE__*/ _jsxs("div", {
                                className: "tour-details-two__overview-bottom-inner",
                                children: [
                                    /*#__PURE__*/ _jsx("div", {
                                        className: "tour-details-two__overview-bottom-left",
                                        children: /*#__PURE__*/ _jsx("ul", {
                                            className: "list-unstyled tour-details-two__overview-bottom-list",
                                            children: overviewList.slice(0, 4).map((over, index)=>/*#__PURE__*/ _jsxs("li", {
                                                    children: [
                                                        /*#__PURE__*/ _jsx("div", {
                                                            className: "icon",
                                                            children: /*#__PURE__*/ _jsx("i", {
                                                                className: "fa fa-check"
                                                            })
                                                        }),
                                                        /*#__PURE__*/ _jsx("div", {
                                                            className: "text",
                                                            children: /*#__PURE__*/ _jsx("p", {
                                                                children: over
                                                            })
                                                        })
                                                    ]
                                                }, index)
                                            )
                                        })
                                    }),
                                    /*#__PURE__*/ _jsx("div", {
                                        className: "tour-details-two__overview-bottom-right",
                                        children: /*#__PURE__*/ _jsx("ul", {
                                            className: "list-unstyled tour-details-two__overview-bottom-right-list",
                                            children: overviewList.slice(4).map((over, index)=>/*#__PURE__*/ _jsxs("li", {
                                                    children: [
                                                        /*#__PURE__*/ _jsx("div", {
                                                            className: "icon",
                                                            children: /*#__PURE__*/ _jsx("i", {
                                                                className: "fa fa-times"
                                                            })
                                                        }),
                                                        /*#__PURE__*/ _jsx("div", {
                                                            className: "text",
                                                            children: /*#__PURE__*/ _jsx("p", {
                                                                children: over
                                                            })
                                                        })
                                                    ]
                                                }, index)
                                            )
                                        })
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ _jsxs("div", {
                className: "tour-details-two__tour-plan",
                children: [
                    /*#__PURE__*/ _jsx("h3", {
                        className: "tour-details-two__title",
                        children: "Tour Plan"
                    }),
                    /*#__PURE__*/ _jsx("div", {
                        className: "accrodion-grp faq-one-accrodion",
                        children: faq.map(({ id , title , text , lists  })=>/*#__PURE__*/ _jsxs("div", {
                                className: `accrodion overflow-hidden${active === id ? " active" : ""}`,
                                children: [
                                    /*#__PURE__*/ _jsx("div", {
                                        onClick: ()=>setActive(id)
                                        ,
                                        className: "accrodion-title",
                                        children: /*#__PURE__*/ _jsxs("h4", {
                                            children: [
                                                /*#__PURE__*/ _jsxs("span", {
                                                    children: [
                                                        "Day ",
                                                        id
                                                    ]
                                                }),
                                                " ",
                                                title
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ _jsx("div", {
                                        className: `accrodion-content animated ${active === id ? "slideInUp d-block" : "slideInDown d-none"}`,
                                        children: /*#__PURE__*/ _jsxs("div", {
                                            className: "inner",
                                            children: [
                                                /*#__PURE__*/ _jsx("p", {
                                                    children: text
                                                }),
                                                /*#__PURE__*/ _jsx("ul", {
                                                    className: "list-unstyled",
                                                    children: lists.map((list, index)=>/*#__PURE__*/ _jsx("li", {
                                                            children: list
                                                        }, index)
                                                    )
                                                })
                                            ]
                                        })
                                    })
                                ]
                            }, id)
                        )
                    })
                ]
            }),
            /*#__PURE__*/ _jsxs("div", {
                className: "tour-details-two__location",
                children: [
                    /*#__PURE__*/ _jsx("h3", {
                        className: "tour-details-two__title",
                        children: "Tour Plan"
                    }),
                    /*#__PURE__*/ _jsx("iframe", {
                        src: "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d4562.753041141002!2d-118.80123790098536!3d34.152323469614075!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x80e82469c2162619%3A0xba03efb7998eef6d!2sCostco+Wholesale!5e0!3m2!1sbn!2sbd!4v1562518641290!5m2!1sbn!2sbd",
                        className: "tour-details-two__location-map",
                        allowFullScreen: true
                    })
                ]
            }),
            /*#__PURE__*/ _jsxs("div", {
                className: "tour-details-two__related-tours",
                children: [
                    /*#__PURE__*/ _jsx("h3", {
                        className: "tour-details-two__title",
                        children: "Tour Plan"
                    }),
                    /*#__PURE__*/ _jsx(Row, {
                        children: popularTours.slice(0, 2).map((tour)=>/*#__PURE__*/ _jsx(Col, {
                                xl: 6,
                                children: /*#__PURE__*/ _jsx(SingleTour, {
                                    tour: tour,
                                    userSelect: true
                                })
                            }, tour.id)
                        )
                    })
                ]
            }),
            /*#__PURE__*/ _jsx("h3", {
                className: "tour-details-two__title review-scores__title",
                children: "Review Scores"
            }),
            /*#__PURE__*/ _jsxs("div", {
                className: "tour-details__review-score",
                children: [
                    /*#__PURE__*/ _jsx("div", {
                        className: "tour-details__review-score-ave",
                        children: /*#__PURE__*/ _jsxs("div", {
                            className: "my-auto",
                            children: [
                                /*#__PURE__*/ _jsx("h3", {
                                    children: TourDetailsLeft_superb
                                }),
                                /*#__PURE__*/ _jsxs("p", {
                                    children: [
                                        /*#__PURE__*/ _jsx("i", {
                                            className: "fa fa-star"
                                        }),
                                        " Super"
                                    ]
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ _jsx("div", {
                        className: "tour-details__review-score__content",
                        children: reviewScore.map((review)=>/*#__PURE__*/ _jsx(ReviewScoreBar, {
                                review: review
                            }, review.id)
                        )
                    })
                ]
            }),
            /*#__PURE__*/ _jsx("div", {
                className: "tour-details__review-comment",
                children: comments.map((comment)=>/*#__PURE__*/ _jsx(SingleComment, {
                        comment: comment
                    }, comment.id)
                )
            }),
            /*#__PURE__*/ _jsx(ReviewForm, {
                reviews: reviews
            })
        ]
    });
};
/* harmony default export */ const TourDetails_TourDetailsLeft = ((/* unused pure expression or super */ null && (TourDetailsLeft_TourDetailsLeft)));

// EXTERNAL MODULE: external "react-datepicker"
var external_react_datepicker_ = __webpack_require__(8743);
// EXTERNAL MODULE: external "react-select"
var external_react_select_ = __webpack_require__(1929);
;// CONCATENATED MODULE: ./src/components/TourDetails/TourDetailsSidebar.js






const typeOptions = [
    "Adventure",
    "Wildlife",
    "Sightseeing"
].map((it)=>({
        value: it,
        label: it
    })
);
const customStyle = {
    valueContainer: (provided)=>({
            ...provided,
            color: "#787780",
            fontSize: 13,
            fontWeight: 500
        })
    ,
    singleValue: (provided)=>({
            ...provided,
            cursor: "pointer"
        })
    ,
    menu: (provided)=>({
            ...provided,
            marginTop: 5,
            border: "none",
            boxShadow: "none",
            zIndex: 10
        })
    ,
    option: (provided, state)=>({
            ...provided,
            color: "white",
            padding: "4px 20px",
            backgroundColor: state.isSelected ? "#e8604c" : "#313041",
            transition: "all 0.4s ease",
            cursor: "pointer",
            borderBottom: state.label === typeOptions[typeOptions.length - 1].label ? "none" : "0.5px solid #ffffff33",
            "&:hover": {
                backgroundColor: "#e8604c"
            },
            borderRadius: state.label === typeOptions[typeOptions.length - 1].label ? "0 0 8px 8px" : 0,
            fontSize: 16,
            fontWeight: 500
        })
    ,
    control: (base)=>({
            ...base,
            borderColor: "transparent",
            boxShadow: "none",
            borderRadius: "8px",
            "&:hover": {
                borderColor: "transparent"
            },
            padding: 14
        })
};
const TourDetailsSidebar_TourDetailsSidebar = ()=>{
    const { 0: type , 1: setType  } = useState("Adventure");
    const { 0: ticket , 1: setTicket  } = useState("Adventure");
    const { 0: startDate , 1: setStartDate  } = useState(new Date());
    const handleSelectType = ({ value  })=>{
        setType(value);
    };
    const handleSelectTicket = ({ value  })=>{
        setTicket(value);
    };
    const handleSubmit = (e)=>{
        e.preventDefault();
        const formData = new FormData(e.target);
        const data = {
            type,
            ticket,
            place: formData.get("place"),
            when: formData.get("when"),
            date: startDate
        };
        console.log(data);
    };
    return /*#__PURE__*/ _jsx("div", {
        className: "tour-details-two__sidebar",
        children: /*#__PURE__*/ _jsxs("div", {
            className: "tour-details-two__book-tours",
            children: [
                /*#__PURE__*/ _jsx("h3", {
                    className: "tour-details-two__sidebar-title",
                    children: "Book Tours"
                }),
                /*#__PURE__*/ _jsx("form", {
                    onSubmit: handleSubmit,
                    className: "tour-details-two__sidebar-form",
                    children: /*#__PURE__*/ _jsx("button", {
                        style: {
                            zIndex: 0
                        },
                        type: "submit",
                        className: "thm-btn tour-details-two__sidebar-btn",
                        children: "Book Now"
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const TourDetails_TourDetailsSidebar = ((/* unused pure expression or super */ null && (TourDetailsSidebar_TourDetailsSidebar)));

;// CONCATENATED MODULE: ./src/components/TourDetails/TourDetailsTwo.js





const TourDetailsTwo = ()=>{
    return /*#__PURE__*/ _jsx("section", {
        className: "tour-details-two",
        children: /*#__PURE__*/ _jsx(Container, {
            children: /*#__PURE__*/ _jsxs(Row, {
                children: [
                    /*#__PURE__*/ _jsx(Col, {
                        xl: 8,
                        lg: 7,
                        children: /*#__PURE__*/ _jsx(TourDetailsLeft, {})
                    }),
                    /*#__PURE__*/ _jsx(Col, {
                        xl: 4,
                        lg: 5,
                        children: /*#__PURE__*/ _jsx(TourDetailsSidebar, {})
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const TourDetails_TourDetailsTwo = ((/* unused pure expression or super */ null && (TourDetailsTwo)));

;// CONCATENATED MODULE: ./src/components/TourDetails/TourDetailsPage.js




const TourDetailsPage = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx(TourDetails_TourDetailsOne, {})
    });
};
/* harmony default export */ const TourDetails_TourDetailsPage = (TourDetailsPage);


/***/ }),

/***/ 5857:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ data_mainSliderTwoData)
});

;// CONCATENATED MODULE: ./src/assets/images/backgrounds/tour-details-bg-1.jpg
/* harmony default export */ const tour_details_bg_1 = ({"src":"/_next/static/media/tour-details-bg-1.496d5409.jpg","height":580,"width":1894,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAIACAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABwEBAAAAAAAAAAAAAAAAAAAAAP/aAAwDAQACEAMQAAAApgP/xAAXEAEAAwAAAAAAAAAAAAAAAAARAAES/9oACAEBAAE/ACtpP//EABQRAQAAAAAAAAAAAAAAAAAAAAD/2gAIAQIBAT8Af//EABQRAQAAAAAAAAAAAAAAAAAAAAD/2gAIAQMBAT8Af//Z"});
;// CONCATENATED MODULE: ./src/assets/images/backgrounds/tour-details-bg-2.jpg
/* harmony default export */ const tour_details_bg_2 = ({"src":"/_next/static/media/tour-details-bg-2.496d5409.jpg","height":580,"width":1894,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAIACAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABwEBAAAAAAAAAAAAAAAAAAAAAP/aAAwDAQACEAMQAAAApgP/xAAXEAEAAwAAAAAAAAAAAAAAAAARAAES/9oACAEBAAE/ACtpP//EABQRAQAAAAAAAAAAAAAAAAAAAAD/2gAIAQIBAT8Af//EABQRAQAAAAAAAAAAAAAAAAAAAAD/2gAIAQMBAT8Af//Z"});
;// CONCATENATED MODULE: ./src/assets/images/backgrounds/tour-details-bg-3.jpg
/* harmony default export */ const tour_details_bg_3 = ({"src":"/_next/static/media/tour-details-bg-3.496d5409.jpg","height":580,"width":1894,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAIACAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABwEBAAAAAAAAAAAAAAAAAAAAAP/aAAwDAQACEAMQAAAApgP/xAAXEAEAAwAAAAAAAAAAAAAAAAARAAES/9oACAEBAAE/ACtpP//EABQRAQAAAAAAAAAAAAAAAAAAAAD/2gAIAQIBAT8Af//EABQRAQAAAAAAAAAAAAAAAAAAAAD/2gAIAQMBAT8Af//Z"});
;// CONCATENATED MODULE: ./src/data/mainSliderTwoData.js



const mainSliderTwoData = [
    {
        id: 1,
        bg: tour_details_bg_1
    },
    {
        id: 2,
        bg: tour_details_bg_2
    },
    {
        id: 3,
        bg: tour_details_bg_3
    }, 
];
/* harmony default export */ const data_mainSliderTwoData = (mainSliderTwoData);


/***/ })

};
;
"use strict";
exports.id = 95;
exports.ids = [95];
exports.modules = {

/***/ 1095:
/***/ (() => {

const popularTours = [
    {
        id: 1,
        image: "popular-tours__img-1.jpg",
        title: "National Park 2 Days Tour",
        superb: "8.0",
        rate: "1870",
        meta: [
            "3 Days",
            "12+",
            "Los Angeles"
        ]
    },
    {
        id: 2,
        image: "popular-tours__img-2.jpg",
        title: "Dark Forest Adventure",
        superb: "8.0",
        rate: "1870",
        meta: [
            "3 Days",
            "12+",
            "Los Angeles"
        ]
    },
    {
        id: 3,
        image: "popular-tours__img-3.jpg",
        title: "Discover Depth of Beach",
        superb: "8.0",
        rate: "1870",
        meta: [
            "3 Days",
            "12+",
            "Los Angeles"
        ]
    },
    {
        id: 4,
        image: "popular-tours__img-4.jpg",
        title: "Moscow Red City Land",
        superb: "8.0",
        rate: "1870",
        meta: [
            "3 Days",
            "12+",
            "Los Angeles"
        ]
    },
    {
        id: 5,
        image: "popular-tours__img-1.jpg",
        title: "Magic of Italy Tours",
        superb: "8.0",
        rate: "1870",
        meta: [
            "3 Days",
            "12+",
            "Los Angeles"
        ]
    },
    {
        id: 6,
        image: "popular-tours__img-2.jpg",
        title: "National Park 2 Days Tour",
        superb: "8.0",
        rate: "1870",
        meta: [
            "3 Days",
            "12+",
            "Los Angeles"
        ]
    },
    {
        id: 7,
        image: "popular-tours__img-3.jpg",
        title: "Discover Depth of Beach",
        superb: "8.0",
        rate: "1870",
        meta: [
            "3 Days",
            "12+",
            "Los Angeles"
        ]
    },
    {
        id: 8,
        image: "popular-tours__img-4.jpg",
        title: "National Park 2 Days Tour",
        superb: "8.0",
        rate: "1870",
        meta: [
            "3 Days",
            "12+",
            "Los Angeles"
        ]
    },
    {
        id: 9,
        image: "popular-tours__img-1.jpg",
        title: "National Park 2 Days Tour",
        superb: "8.0",
        rate: "1870",
        meta: [
            "3 Days",
            "12+",
            "Los Angeles"
        ]
    },
    {
        id: 10,
        image: "popular-tours__img-2.jpg",
        title: "National Park 2 Days Tour",
        superb: "8.0",
        rate: "1870",
        meta: [
            "3 Days",
            "12+",
            "Los Angeles"
        ]
    },
    {
        id: 11,
        image: "popular-tours__img-3.jpg",
        title: "National Park 2 Days Tour",
        superb: "8.0",
        rate: "1870",
        meta: [
            "3 Days",
            "12+",
            "Los Angeles"
        ]
    },
    {
        id: 12,
        image: "popular-tours__img-4.jpg",
        title: "National Park 2 Days Tour",
        superb: "8.0",
        rate: "1870",
        meta: [
            "3 Days",
            "12+",
            "Los Angeles"
        ]
    }, 
];
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (popularTours)));


/***/ })

};
;